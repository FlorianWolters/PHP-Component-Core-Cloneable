
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","FlorianWolters\\Component\\Core\\CloneableInterface"],["c","FlorianWolters\\Component\\Core\\CloneNotSupportedException"],["c","FlorianWolters\\Component\\Core\\CloneNotSupportedTrait"]];
